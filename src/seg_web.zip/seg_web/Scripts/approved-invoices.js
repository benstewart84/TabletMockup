﻿$(document).ready(function () {

    var helper = new CommonHelpers();
    helper.initialiseDatePickers();

});