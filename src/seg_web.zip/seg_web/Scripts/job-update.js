﻿function CertificateRequired() {
    // Show Cert Type, only if Cert is required.
    var selectedVal = $(".elecCertRequired").find(":selected").val();
    if (selectedVal === "1") {
        $('#electCertType').show(1000);
    } else {
        $('#electCertType').slideUp(500);
    }
};

$(document).ready(function () {
    debugger;
    $('.elecCertRequired').on("change", function () {
        CertificateRequired();
    });
});
